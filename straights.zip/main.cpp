#include "Table.h"
#include "Player.h"

int main(int argc, char **argv){
	Table table = Table(argc, argv);
	return 0;
}
